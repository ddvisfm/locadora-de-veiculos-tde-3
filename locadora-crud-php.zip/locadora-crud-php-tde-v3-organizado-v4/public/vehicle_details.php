<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();
$id = require_int($_GET['id'] ?? null);

$stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id=?");
$stmt->execute([$id]);
$v = $stmt->fetch();
if (!$v) throw new Exception('Veículo não encontrado.');

render('vehicle_details', ['v' => $v]);

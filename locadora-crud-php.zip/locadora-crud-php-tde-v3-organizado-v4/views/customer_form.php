<?php
/** @var bool $editing */
/** @var array $customer */
?>
<h1><?= $editing ? 'Editar cliente' : 'Novo cliente' ?></h1>

<div class="card">
  <form method="post">
    <label class="label">Nome</label>
    <input class="input" name="name" value="<?= h((string)$customer['name']) ?>" required>

    <div class="row">
      <div class="col">
        <label class="label">CPF</label>
        <input class="input" name="cpf" value="<?= h((string)$customer['cpf']) ?>" required>
      </div>
      <div class="col">
        <label class="label">CNH</label>
        <input class="input" name="cnh" value="<?= h((string)$customer['cnh']) ?>" required>
      </div>
      <div class="col">
        <label class="label">Contato</label>
        <input class="input" name="contact" value="<?= h((string)$customer['contact']) ?>" required>
      </div>
    </div>

    <div class="form-actions">
      <button class="btn" type="submit">Salvar</button>
      <a class="btn light" href="customers.php">Voltar</a>
    </div>
  </form>
</div>

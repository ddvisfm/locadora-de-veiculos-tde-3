# Locadora de Veículos (PHP + MySQL) - TDE CRUD (v3)

Versão mais simples: removidos os campos de **descrição** e **regras** do veículo.

Fluxo:
- Busca por veículos disponíveis (retirada/devolução)
- Listagem de veículos (categoria, diária, reservar)
- Detalhes do veículo (informações básicas + valor)
- Cadastro de cliente (nome, CPF, CNH, contato)
- Reservas: criar, editar, cancelar, listar
- Status: reservado, em_andamento, finalizado, cancelado
- Cálculo simples por diárias
- Admin veículos: CRUD completo

## Rodar (XAMPP)
1) No phpMyAdmin, rode/importe `database/schema.sql`
   - Esse SQL derruba e recria as tabelas (evita coluna faltando).
2) Acesse: `http://localhost/locadora-crud-php-tde-v3/public/`


## Organização (separação de HTML)
- Controllers em `public/` (PHP com lógica)
- Views em `views/` (HTML)
- CSS em `public/assets/`

<?php
require_once __DIR__ . '/../app/bootstrap.php';
try {
  $pdo = db();
  $id = require_int($_GET['id'] ?? null);
  $stmt = $pdo->prepare("SELECT status FROM reservations WHERE id=?");
  $stmt->execute([$id]);
  $r = $stmt->fetch();
  if (!$r) throw new Exception('Reserva não encontrada.');
  if (!in_array($r['status'], ['reservado','em_andamento'], true)) throw new Exception('Só cancela reserva ativa.');
  $stmt = $pdo->prepare("UPDATE reservations SET status='cancelado' WHERE id=?");
  $stmt->execute([$id]);
  set_flash('success','Reserva cancelada.');
} catch (Exception $e) { set_flash('error',$e->getMessage()); }
redirect('reservations.php');

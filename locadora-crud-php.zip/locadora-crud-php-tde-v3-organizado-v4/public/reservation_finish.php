<?php
require_once __DIR__ . '/../app/bootstrap.php';
try {
  $pdo = db();
  $id = require_int($_GET['id'] ?? null);
  $stmt = $pdo->prepare("SELECT * FROM reservations WHERE id=?");
  $stmt->execute([$id]);
  $r = $stmt->fetch();
  if (!$r) throw new Exception('Reserva não encontrada.');
  if ($r['status']!=='em_andamento') throw new Exception('Só finaliza quando está em_andamento.');

  $start = parse_date($r['pickup_date']);
  $end = new DateTime('today');
  $days = rental_days($start,$end);
  $total = $days * (float)$r['daily_rate'];

  $stmt = $pdo->prepare("UPDATE reservations SET status='finalizado', return_date_actual=?, total_final=? WHERE id=?");
  $stmt->execute([$end->format('Y-m-d'), $total, $id]);

  set_flash('success','Finalizado. Total: R$ '.to_money($total));
} catch (Exception $e) { set_flash('error',$e->getMessage()); }
redirect('reservations.php');

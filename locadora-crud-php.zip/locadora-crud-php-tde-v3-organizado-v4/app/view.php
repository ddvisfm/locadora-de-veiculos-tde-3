<?php
// Renderização simples de views (separação do HTML do controller).
// Uso: render('index', ['var' => $valor]);

function render(string $view, array $data = []): void {
  extract($data, EXTR_SKIP);

  require __DIR__ . '/../views/layout/header.php';
  require __DIR__ . '/../views/' . $view . '.php';

  // Sem arquivo de footer. Apenas fechamos as tags abertas no header.
  echo "\n  </main>\n</body>\n</html>\n";
}

<?php
// Layout HTML (view). Aqui fica o HTML comum do site.
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Locadora</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <main class="container">
    <p class="small">
      <a href="index.php">Busca</a> |
      <a href="vehicles.php">Veículos</a> |
      <a href="vehicle_admin.php">Admin veículos</a> |
      <a href="customers.php">Clientes</a> |
      <a href="reservations.php">Reservas</a>
    </p>

    <?php $flash = get_flash(); ?>
    <?php if ($flash): ?>
      <div class="flash <?= h($flash['type']) ?>"><?= h($flash['message']) ?></div>
    <?php endif; ?>

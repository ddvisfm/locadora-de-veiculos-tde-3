CREATE DATABASE IF NOT EXISTS locadora
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE locadora;

DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS vehicles;

CREATE TABLE vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate VARCHAR(10) NOT NULL UNIQUE,
  brand VARCHAR(60) NOT NULL,
  model VARCHAR(80) NOT NULL,
  year INT NOT NULL,
  category ENUM('economico','sedan','suv') NOT NULL DEFAULT 'economico',
  daily_rate DECIMAL(10,2) NOT NULL,
  status ENUM('ativo','manutencao') NOT NULL DEFAULT 'ativo',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  cnh VARCHAR(20) NOT NULL,
  contact VARCHAR(120) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vehicle_id INT NOT NULL,
  customer_id INT NOT NULL,
  pickup_date DATE NOT NULL,
  return_date DATE NOT NULL,
  return_date_actual DATE NULL,
  daily_rate DECIMAL(10,2) NOT NULL,
  total_estimate DECIMAL(10,2) NOT NULL,
  total_final DECIMAL(10,2) NULL,
  status ENUM('reservado','em_andamento','finalizado','cancelado') NOT NULL DEFAULT 'reservado',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_res_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON UPDATE CASCADE,
  CONSTRAINT fk_res_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON UPDATE CASCADE
);

CREATE INDEX idx_vehicle_status ON vehicles(status);
CREATE INDEX idx_res_status ON reservations(status);
CREATE INDEX idx_res_dates ON reservations(pickup_date, return_date);

<?php
require_once __DIR__ . '/../app/bootstrap.php';
try {
  $pdo = db();
  $id = require_int($_GET['id'] ?? null);
  $stmt = $pdo->prepare("DELETE FROM reservations WHERE id=?");
  $stmt->execute([$id]);
  set_flash('success','Registro excluído.');
} catch (Exception $e) { set_flash('error',$e->getMessage()); }
redirect('reservations.php');

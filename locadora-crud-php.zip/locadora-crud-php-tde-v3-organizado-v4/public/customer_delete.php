<?php
require_once __DIR__ . '/../app/bootstrap.php';
try {
  $pdo = db();
  $id = require_int($_GET['id'] ?? null);
  $stmt = $pdo->prepare("SELECT COUNT(*) AS c FROM reservations WHERE customer_id=? AND status IN ('reservado','em_andamento')");
  $stmt->execute([$id]);
  if ((int)$stmt->fetch()['c']>0) throw new Exception('Não dá para excluir: cliente tem reserva ativa.');
  $stmt = $pdo->prepare("DELETE FROM customers WHERE id=?");
  $stmt->execute([$id]);
  set_flash('success','Cliente excluído.');
} catch (Exception $e) { set_flash('error',$e->getMessage()); }
redirect('customers.php');

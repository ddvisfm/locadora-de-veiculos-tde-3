<?php
/** @var array $res */
?>
<h1>Reservas</h1>

<div class="form-actions">
  <a class="btn" href="reservation_new.php">Nova reserva</a>
</div>

<table class="table">
  <thead><tr><th>ID</th><th>Veículo</th><th>Cliente</th><th>Período</th><th>Status</th><th>Estimativa</th><th>Final</th><th>Ações</th></tr></thead>
  <tbody>
    <?php foreach ($res as $r): ?>
      <tr>
        <td><?= h((string)$r['id']) ?></td>
        <td><?= h($r['brand']) ?> <?= h($r['model']) ?> (<?= h($r['plate']) ?>)</td>
        <td><?= h($r['customer_name']) ?> (<?= h($r['cpf']) ?>)</td>
        <td><?= h($r['pickup_date']) ?> → <?= h($r['return_date']) ?></td>
        <td><span class="badge"><?= h($r['status']) ?></span></td>
        <td>R$ <?= h(to_money($r['total_estimate'])) ?></td>
        <td><?= $r['total_final']!==null ? 'R$ '.h(to_money($r['total_final'])) : '-' ?></td>
        <td class="actions">
          <?php if ($r['status']==='reservado'): ?>
            <a class="btn secondary" href="reservation_edit.php?id=<?= h((string)$r['id']) ?>">Editar</a>
            <a class="btn" href="reservation_start.php?id=<?= h((string)$r['id']) ?>" onclick="return confirm('Iniciar?');">Iniciar</a>
            <a class="btn danger" href="reservation_cancel.php?id=<?= h((string)$r['id']) ?>" onclick="return confirm('Cancelar?');">Cancelar</a>
          <?php elseif ($r['status']==='em_andamento'): ?>
            <a class="btn" href="reservation_finish.php?id=<?= h((string)$r['id']) ?>" onclick="return confirm('Finalizar?');">Finalizar</a>
            <a class="btn danger" href="reservation_cancel.php?id=<?= h((string)$r['id']) ?>" onclick="return confirm('Cancelar?');">Cancelar</a>
          <?php endif; ?>
          <a class="btn light" href="reservation_delete.php?id=<?= h((string)$r['id']) ?>" onclick="return confirm('Excluir registro?');">Excluir</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (count($res)===0): ?>
      <tr><td colspan="8">Nenhuma reserva.</td></tr>
    <?php endif; ?>
  </tbody>
</table>

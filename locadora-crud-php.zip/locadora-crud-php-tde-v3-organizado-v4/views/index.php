<?php
/** @var string $pickup */
/** @var string $return */
/** @var bool $searched */
/** @var array $vehicles */
?>
<h1>Busca de veículos</h1>

<div class="card">
  <form method="get">
    <div class="row">
      <div class="col">
        <label class="label">Retirada</label>
        <input class="input" type="date" name="pickup_date" value="<?= h($pickup) ?>" required>
      </div>
      <div class="col">
        <label class="label">Devolução</label>
        <input class="input" type="date" name="return_date" value="<?= h($return) ?>" required>
      </div>
    </div>
    <div class="form-actions">
      <button class="btn" type="submit">Buscar</button>
    </div>
  </form>
</div>

<?php if ($searched): ?>
  <h1>Disponíveis</h1>
  <table class="table">
    <thead><tr><th>Veículo</th><th>Categoria</th><th>Diária</th><th>Ações</th></tr></thead>
    <tbody>
      <?php foreach ($vehicles as $v): ?>
        <tr>
          <td><?= h($v['brand']) ?> <?= h($v['model']) ?> (<?= h($v['plate']) ?>)</td>
          <td><?= h(category_label($v['category'])) ?></td>
          <td>R$ <?= h(to_money($v['daily_rate'])) ?></td>
          <td class="actions">
            <a class="btn light" href="vehicle_details.php?id=<?= h((string)$v['id']) ?>">Detalhes</a>
            <a class="btn" href="reservation_new.php?vehicle_id=<?= h((string)$v['id']) ?>&pickup_date=<?= h($pickup) ?>&return_date=<?= h($return) ?>">Reservar</a>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (count($vehicles) === 0): ?>
        <tr><td colspan="4">Nenhum veículo disponível para o período.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
<?php endif; ?>

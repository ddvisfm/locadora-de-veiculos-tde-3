<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();

$id = $_GET['id'] ?? null;
$editing = $id !== null;

$customer = ['name'=>'','cpf'=>'','cnh'=>'','contact'=>''];

if ($editing) {
  $id = require_int($id);
  $stmt = $pdo->prepare("SELECT * FROM customers WHERE id=?");
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  if (!$row) { set_flash('error','Cliente não encontrado.'); redirect('customers.php'); }
  $customer = array_merge($customer, $row);
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    $name = trim($_POST['name'] ?? '');
    $cpf = trim($_POST['cpf'] ?? '');
    $cnh = trim($_POST['cnh'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    if ($name===''||$cpf===''||$cnh===''||$contact==='') throw new Exception('Preencha nome, CPF, CNH e contato.');

    $cpf_digits = preg_replace('/\D+/', '', $cpf);
    if (strlen($cpf_digits)!==11) throw new Exception('CPF inválido (11 dígitos).');

    if ($editing) {
      $stmt = $pdo->prepare("UPDATE customers SET name=?, cpf=?, cnh=?, contact=? WHERE id=?");
      $stmt->execute([$name,$cpf,$cnh,$contact,$id]);
      set_flash('success','Cliente atualizado.');
    } else {
      $stmt = $pdo->prepare("INSERT INTO customers (name, cpf, cnh, contact) VALUES (?,?,?,?)");
      $stmt->execute([$name,$cpf,$cnh,$contact]);
      set_flash('success','Cliente criado.');
    }
    redirect('customers.php');
  } catch (Exception $e) {
    set_flash('error', $e->getMessage());
    $customer = ['name'=>$name,'cpf'=>$cpf,'cnh'=>$cnh,'contact'=>$contact];
  }
}

render('customer_form', [
  'editing' => $editing,
  'customer' => $customer,
]);

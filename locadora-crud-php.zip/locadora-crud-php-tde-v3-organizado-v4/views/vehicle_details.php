<?php
/** @var array $v */
?>
<h1>Detalhes do veículo</h1>

<div class="card">
  <p><b>Veículo:</b> <?= h($v['brand']) ?> <?= h($v['model']) ?> (<?= h($v['plate']) ?>)</p>
  <p><b>Ano:</b> <?= h((string)$v['year']) ?></p>
  <p><b>Categoria:</b> <?= h(category_label($v['category'])) ?></p>
  <p><b>Diária:</b> R$ <?= h(to_money($v['daily_rate'])) ?></p>

  <div class="form-actions">
    <a class="btn" href="reservation_new.php?vehicle_id=<?= h((string)$v['id']) ?>">Reservar</a>
    <a class="btn light" href="vehicles.php">Voltar</a>
  </div>
</div>

<?php
/** @var array $vehicles */
?>
<h1>Admin veículos (CRUD)</h1>

<div class="form-actions">
  <a class="btn" href="vehicle_form.php">Novo veículo</a>
</div>

<table class="table">
  <thead><tr><th>ID</th><th>Placa</th><th>Veículo</th><th>Categoria</th><th>Diária</th><th>Status</th><th>Ações</th></tr></thead>
  <tbody>
    <?php foreach ($vehicles as $v): ?>
      <tr>
        <td><?= h((string)$v['id']) ?></td>
        <td><?= h($v['plate']) ?></td>
        <td><?= h($v['brand']) ?> <?= h($v['model']) ?> (<?= h((string)$v['year']) ?>)</td>
        <td><?= h(category_label($v['category'])) ?></td>
        <td>R$ <?= h(to_money($v['daily_rate'])) ?></td>
        <td><span class="badge"><?= h($v['status']) ?></span></td>
        <td class="actions">
          <a class="btn secondary" href="vehicle_form.php?id=<?= h((string)$v['id']) ?>">Editar</a>
          <a class="btn danger" href="vehicle_delete.php?id=<?= h((string)$v['id']) ?>" onclick="return confirm('Excluir veículo?');">Excluir</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (count($vehicles)===0): ?><tr><td colspan="7">Nenhum veículo.</td></tr><?php endif; ?>
  </tbody>
</table>

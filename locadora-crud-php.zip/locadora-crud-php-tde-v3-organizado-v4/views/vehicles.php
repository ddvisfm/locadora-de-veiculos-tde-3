<?php
/** @var array $vehicles */
?>
<h1>Listagem de veículos</h1>

<table class="table">
  <thead><tr><th>Veículo</th><th>Categoria</th><th>Diária</th><th>Ações</th></tr></thead>
  <tbody>
    <?php foreach ($vehicles as $v): ?>
      <tr>
        <td><?= h($v['brand']) ?> <?= h($v['model']) ?> (<?= h($v['plate']) ?>)</td>
        <td><?= h(category_label($v['category'])) ?></td>
        <td>R$ <?= h(to_money($v['daily_rate'])) ?></td>
        <td class="actions">
          <a class="btn light" href="vehicle_details.php?id=<?= h((string)$v['id']) ?>">Detalhes</a>
          <a class="btn" href="reservation_new.php?vehicle_id=<?= h((string)$v['id']) ?>">Reservar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (count($vehicles)===0): ?>
      <tr><td colspan="4">Nenhum veículo ativo.</td></tr>
    <?php endif; ?>
  </tbody>
</table>

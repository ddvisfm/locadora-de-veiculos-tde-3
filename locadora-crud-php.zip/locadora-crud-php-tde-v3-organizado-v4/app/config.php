<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'locadora');
define('DB_USER', 'root');
define('DB_PASS', '');
date_default_timezone_set('America/Fortaleza');

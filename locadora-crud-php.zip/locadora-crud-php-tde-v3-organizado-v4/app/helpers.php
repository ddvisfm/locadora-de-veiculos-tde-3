<?php
function h(string $value): string { return htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $path): void { header('Location: ' . $path); exit; }
function set_flash(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type,'message'=>$message]; }
function get_flash(): ?array { if (!isset($_SESSION['flash'])) return null; $f=$_SESSION['flash']; unset($_SESSION['flash']); return $f; }
function require_int($value): int { if (!isset($value)||!is_numeric($value)) throw new Exception('ID inválido.'); return (int)$value; }
function to_money($value): string { return number_format((float)$value, 2, ',', '.'); }
function parse_date(string $value): DateTime {
  $dt = DateTime::createFromFormat('Y-m-d', $value);
  if (!$dt) throw new Exception('Data inválida.');
  $dt->setTime(0,0,0);
  return $dt;
}
function rental_days(DateTime $start, DateTime $end): int { $d=(int)$start->diff($end)->days; return max(1, $d+1); }
function category_label(string $cat): string {
  return match($cat) { 'economico'=>'Econômico','sedan'=>'Sedan','suv'=>'SUV', default=>$cat };
}

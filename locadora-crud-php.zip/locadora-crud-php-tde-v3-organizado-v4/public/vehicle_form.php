<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();

$id = $_GET['id'] ?? null;
$editing = $id !== null;

$vehicle = [
  'plate'=>'','brand'=>'','model'=>'','year'=>'',
  'category'=>'economico','daily_rate'=>'','status'=>'ativo'
];

if ($editing) {
  $id = require_int($id);
  $stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id=?");
  $stmt->execute([$id]);
  $row = $stmt->fetch();
  if (!$row) { set_flash('error','Veículo não encontrado.'); redirect('vehicle_admin.php'); }
  $vehicle = array_merge($vehicle, $row);
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  // Pré-ler POST para não gerar variáveis indefinidas no catch (e para o VS Code parar de marcar erro)
  $plate_raw = strtoupper(trim($_POST['plate'] ?? ''));
  $brand_raw = trim($_POST['brand'] ?? '');
  $model_raw = trim($_POST['model'] ?? '');
  $year_raw = (int)($_POST['year'] ?? 0);
  $category_raw = $_POST['category'] ?? 'economico';
  $daily_rate_raw = $_POST['daily_rate'] ?? '';
  $status_raw = $_POST['status'] ?? 'ativo';

  try {
    $plate = $plate_raw;
    $brand = $brand_raw;
    $model = $model_raw;
    $year = $year_raw;
    $category = $category_raw;
    $daily_rate = (float)str_replace(',', '.', $daily_rate_raw);
    $status = $status_raw;

    if ($plate===''||$brand===''||$model==='') throw new Exception('Placa, marca e modelo são obrigatórios.');
    if ($year<1900 || $year>((int)date('Y')+1)) throw new Exception('Ano inválido.');
    if (!in_array($category,['economico','sedan','suv'],true)) throw new Exception('Categoria inválida.');
    if ($daily_rate<=0) throw new Exception('Diária deve ser maior que zero.');
    if (!in_array($status,['ativo','manutencao'],true)) throw new Exception('Status inválido.');

    if ($editing) {
      $stmt = $pdo->prepare("UPDATE vehicles SET plate=?, brand=?, model=?, year=?, category=?, daily_rate=?, status=? WHERE id=?");
      $stmt->execute([$plate,$brand,$model,$year,$category,$daily_rate,$status,$id]);
      set_flash('success','Veículo atualizado.');
    } else {
      $stmt = $pdo->prepare("INSERT INTO vehicles (plate, brand, model, year, category, daily_rate, status) VALUES (?,?,?,?,?,?,?)");
      $stmt->execute([$plate,$brand,$model,$year,$category,$daily_rate,$status]);
      set_flash('success','Veículo criado.');
    }
    redirect('vehicle_admin.php');
  } catch (Exception $e) {
    set_flash('error',$e->getMessage());
    // Repreenche o formulário com o que o usuário digitou
    $vehicle = [
      'plate' => $plate_raw,
      'brand' => $brand_raw,
      'model' => $model_raw,
      'year' => $year_raw,
      'category' => $category_raw,
      'daily_rate' => $daily_rate_raw,
      'status' => $status_raw,
    ];
  }
}


render('vehicle_form', [
  'editing' => $editing,
  'vehicle' => $vehicle,
]);

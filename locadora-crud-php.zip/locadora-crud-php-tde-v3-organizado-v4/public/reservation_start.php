<?php
require_once __DIR__ . '/../app/bootstrap.php';
try {
  $pdo = db();
  $id = require_int($_GET['id'] ?? null);
  $stmt = $pdo->prepare("SELECT status FROM reservations WHERE id=?");
  $stmt->execute([$id]);
  $r = $stmt->fetch();
  if (!$r) throw new Exception('Reserva não encontrada.');
  if ($r['status']!=='reservado') throw new Exception('Só inicia quando está reservado.');
  $stmt = $pdo->prepare("UPDATE reservations SET status='em_andamento' WHERE id=?");
  $stmt->execute([$id]);
  set_flash('success','Status: em_andamento.');
} catch (Exception $e) { set_flash('error',$e->getMessage()); }
redirect('reservations.php');

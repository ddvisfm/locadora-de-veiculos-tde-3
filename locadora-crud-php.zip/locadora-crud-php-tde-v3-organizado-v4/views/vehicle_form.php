<?php
/** @var bool $editing */
/** @var array $vehicle */
?>
<h1><?= $editing ? 'Editar veículo' : 'Novo veículo' ?></h1>

<div class="card">
  <form method="post">
    <label class="label">Placa</label>
    <input class="input" name="plate" value="<?= h((string)($vehicle['plate'] ?? '')) ?>" required>

    <div class="row">
      <div class="col">
        <label class="label">Marca</label>
        <input class="input" name="brand" value="<?= h((string)($vehicle['brand'] ?? '')) ?>" required>
      </div>
      <div class="col">
        <label class="label">Modelo</label>
        <input class="input" name="model" value="<?= h((string)($vehicle['model'] ?? '')) ?>" required>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <label class="label">Ano</label>
        <input class="input" type="number" name="year" value="<?= h((string)($vehicle['year'] ?? '')) ?>" required>
      </div>
      <div class="col">
        <label class="label">Categoria</label>
        <select class="input" name="category" required>
          <option value="economico" <?= (($vehicle['category'] ?? 'economico')==='economico')?'selected':''; ?>>Econômico</option>
          <option value="sedan" <?= (($vehicle['category'] ?? '')==='sedan')?'selected':''; ?>>Sedan</option>
          <option value="suv" <?= (($vehicle['category'] ?? '')==='suv')?'selected':''; ?>>SUV</option>
        </select>
      </div>
      <div class="col">
        <label class="label">Diária (R$)</label>
        <input class="input" name="daily_rate" value="<?= h((string)($vehicle['daily_rate'] ?? '')) ?>" placeholder="150.00" required>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <label class="label">Status</label>
        <select class="input" name="status">
          <option value="ativo" <?= (($vehicle['status'] ?? 'ativo')==='ativo')?'selected':''; ?>>ativo</option>
          <option value="manutencao" <?= (($vehicle['status'] ?? '')==='manutencao')?'selected':''; ?>>manutencao</option>
        </select>
      </div>
    </div>

    <div class="form-actions">
      <button class="btn" type="submit">Salvar</button>
      <a class="btn light" href="vehicle_admin.php">Voltar</a>
    </div>
  </form>
</div>

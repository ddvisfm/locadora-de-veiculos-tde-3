<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();
$res = $pdo->query("
  SELECT r.*, v.plate, v.brand, v.model, c.name AS customer_name, c.cpf
  FROM reservations r
  JOIN vehicles v ON v.id=r.vehicle_id
  JOIN customers c ON c.id=r.customer_id
  ORDER BY r.id DESC
")->fetchAll();

render('reservations', ['res' => $res]);

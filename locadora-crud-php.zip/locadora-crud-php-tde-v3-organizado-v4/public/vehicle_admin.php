<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();
$vehicles = $pdo->query("SELECT * FROM vehicles ORDER BY id DESC")->fetchAll();

render('vehicle_admin', ['vehicles' => $vehicles]);

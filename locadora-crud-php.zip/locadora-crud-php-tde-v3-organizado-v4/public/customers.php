<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();
$customers = $pdo->query("SELECT * FROM customers ORDER BY id DESC")->fetchAll();

render('customers', ['customers' => $customers]);

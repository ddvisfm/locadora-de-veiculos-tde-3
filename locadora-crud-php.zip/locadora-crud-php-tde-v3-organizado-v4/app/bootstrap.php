<?php
ini_set('display_errors','1');
ini_set('display_startup_errors','1');
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/view.php';

set_exception_handler(function(Throwable $e) {
  http_response_code(500);
  echo '<h3>Erro</h3>';
  echo '<pre style="white-space:pre-wrap;">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre>';
  echo '<p><a href="index.php">Voltar</a></p>';
  exit;
});

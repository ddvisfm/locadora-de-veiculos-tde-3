<?php
/** @var bool $editing */
/** @var array $vehicles */
/** @var array $customers */
/** @var string $vehicle_id */
/** @var string $customer_id */
/** @var string $pickup_date */
/** @var string $return_date */
?>
<h1><?= $editing ? 'Editar reserva' : 'Nova reserva' ?></h1>

<?php if (!$editing && count($customers)===0): ?>
  <div class="card">
    <b>Cadastre um cliente antes de reservar.</b>
    <div class="form-actions"><a class="btn" href="customer_form.php">Novo cliente</a></div>
  </div>
<?php endif; ?>

<div class="card">
  <form method="post">
    <label class="label">Veículo</label>
    <select class="input" name="vehicle_id" required>
      <option value="">Selecione</option>
      <?php foreach ($vehicles as $v): ?>
        <option value="<?= h((string)$v['id']) ?>" <?= ((string)$vehicle_id===(string)$v['id'])?'selected':''; ?>>
          <?= h($v['plate']) ?> - <?= h($v['brand']) ?> <?= h($v['model']) ?> (<?= h(category_label($v['category'])) ?>) R$ <?= h(to_money($v['daily_rate'])) ?>/dia
        </option>
      <?php endforeach; ?>
    </select>

    <label class="label">Cliente</label>
    <select class="input" name="customer_id" required>
      <option value="">Selecione</option>
      <?php foreach ($customers as $c): ?>
        <option value="<?= h((string)$c['id']) ?>" <?= ((string)$customer_id===(string)$c['id'])?'selected':''; ?>>
          <?= h($c['name']) ?> (<?= h($c['cpf']) ?>)
        </option>
      <?php endforeach; ?>
    </select>

    <div class="row">
      <div class="col">
        <label class="label">Retirada</label>
        <input class="input" type="date" name="pickup_date" value="<?= h($pickup_date) ?>" required>
      </div>
      <div class="col">
        <label class="label">Devolução</label>
        <input class="input" type="date" name="return_date" value="<?= h($return_date) ?>" required>
      </div>
    </div>

    <div class="form-actions">
      <button class="btn" type="submit">Salvar</button>
      <a class="btn light" href="reservations.php">Voltar</a>
    </div>
  </form>
</div>

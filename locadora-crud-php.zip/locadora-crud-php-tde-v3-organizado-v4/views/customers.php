<?php
/** @var array $customers */
?>
<h1>Cadastro de clientes</h1>

<div class="form-actions">
  <a class="btn" href="customer_form.php">Novo cliente</a>
</div>

<table class="table">
  <thead><tr><th>ID</th><th>Nome</th><th>CPF</th><th>CNH</th><th>Contato</th><th>Ações</th></tr></thead>
  <tbody>
    <?php foreach ($customers as $c): ?>
      <tr>
        <td><?= h((string)$c['id']) ?></td>
        <td><?= h($c['name']) ?></td>
        <td><?= h($c['cpf']) ?></td>
        <td><?= h($c['cnh']) ?></td>
        <td><?= h($c['contact']) ?></td>
        <td class="actions">
          <a class="btn secondary" href="customer_form.php?id=<?= h((string)$c['id']) ?>">Editar</a>
          <a class="btn danger" href="customer_delete.php?id=<?= h((string)$c['id']) ?>" onclick="return confirm('Excluir cliente?');">Excluir</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (count($customers)===0): ?>
      <tr><td colspan="6">Nenhum cliente.</td></tr>
    <?php endif; ?>
  </tbody>
</table>

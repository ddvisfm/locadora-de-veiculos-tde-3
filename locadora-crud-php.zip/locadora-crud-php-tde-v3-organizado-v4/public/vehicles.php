<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();
$vehicles = $pdo->query("SELECT * FROM vehicles WHERE status='ativo' ORDER BY id DESC")->fetchAll();

render('vehicles', ['vehicles' => $vehicles]);

<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();

$pickup = $_GET['pickup_date'] ?? date('Y-m-d');
$return = $_GET['return_date'] ?? date('Y-m-d', strtotime('+1 day'));

$searched = isset($_GET['pickup_date'], $_GET['return_date']);
$vehicles = [];

if ($searched) {
  $start = parse_date($pickup);
  $end = parse_date($return);
  if ($end < $start) { set_flash('error','Data de devolução não pode ser anterior à retirada.'); redirect('index.php'); }

  $sql = "
    SELECT v.*
    FROM vehicles v
    WHERE v.status='ativo'
      AND v.id NOT IN (
        SELECT r.vehicle_id
        FROM reservations r
        WHERE r.status IN ('reservado','em_andamento')
          AND NOT (r.return_date < :pickup OR r.pickup_date > :return)
      )
    ORDER BY v.id DESC
  ";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([':pickup'=>$pickup, ':return'=>$return]);
  $vehicles = $stmt->fetchAll();
}

render('index', [
  'pickup' => $pickup,
  'return' => $return,
  'searched' => $searched,
  'vehicles' => $vehicles,
]);

<?php
require_once __DIR__ . '/../app/bootstrap.php';

$pdo = db();

$vehicle_id = $_GET['vehicle_id'] ?? ($_POST['vehicle_id'] ?? '');
$pickup_date = $_GET['pickup_date'] ?? ($_POST['pickup_date'] ?? date('Y-m-d'));
$return_date = $_GET['return_date'] ?? ($_POST['return_date'] ?? date('Y-m-d', strtotime('+1 day')));

$customers = $pdo->query("SELECT id, name, cpf FROM customers ORDER BY id DESC")->fetchAll();
$vehicles = $pdo->query("SELECT id, plate, brand, model, daily_rate, category FROM vehicles WHERE status='ativo' ORDER BY id DESC")->fetchAll();

$customer_id = $_POST['customer_id'] ?? '';

$editing = false;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    $vid = require_int($_POST['vehicle_id'] ?? null);
    $cid = require_int($_POST['customer_id'] ?? null);
    $start = parse_date($_POST['pickup_date'] ?? '');
    $end = parse_date($_POST['return_date'] ?? '');
    if ($end < $start) throw new Exception('Devolução não pode ser anterior à retirada.');

    $stmt = $pdo->prepare("SELECT * FROM vehicles WHERE id=? AND status='ativo'");
    $stmt->execute([$vid]);
    $v = $stmt->fetch();
    if (!$v) throw new Exception('Veículo não encontrado/ativo.');

    $stmt = $pdo->prepare("SELECT id FROM customers WHERE id=?");
    $stmt->execute([$cid]);
    if (!$stmt->fetch()) throw new Exception('Cliente não encontrado.');

    $sql = "SELECT COUNT(*) AS c FROM reservations
            WHERE vehicle_id=:vid AND status IN ('reservado','em_andamento')
              AND NOT (return_date < :pickup OR pickup_date > :return)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':vid'=>$vid, ':pickup'=>$start->format('Y-m-d'), ':return'=>$end->format('Y-m-d')]);
    if ((int)$stmt->fetch()['c']>0) throw new Exception('Veículo indisponível no período.');

    $days = rental_days($start,$end);
    $daily = (float)$v['daily_rate'];
    $estimate = $days * $daily;

    $stmt = $pdo->prepare("INSERT INTO reservations (vehicle_id, customer_id, pickup_date, return_date, daily_rate, total_estimate, status)
                           VALUES (?,?,?,?,?,?, 'reservado')");
    $stmt->execute([$vid,$cid,$start->format('Y-m-d'),$end->format('Y-m-d'),$daily,$estimate]);

    set_flash('success','Reserva criada. Estimativa: R$ '.to_money($estimate));
    redirect('reservations.php');
  } catch (Exception $e) {
    set_flash('error',$e->getMessage());
  }
}

render('reservation_form', [
  'editing' => $editing,
  'vehicles' => $vehicles,
  'customers' => $customers,
  'vehicle_id' => (string)$vehicle_id,
  'customer_id' => (string)$customer_id,
  'pickup_date' => $pickup_date,
  'return_date' => $return_date,
]);
